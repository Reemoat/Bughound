<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Final Version</title>
    </head>
    <body>
        <h1>Welcome To Bug Hound</h1>
        <h2>By:</h2>
        <h2>Bertrand Ithurburn</h2>
        <h2>Daniel Hardy</h2>
        <A HREF="EnterNewReport.php"><b>Enter New Bug Report</b></A><br>
        <A HREF="SearchBugReports.php"><b>Edit/Search Bug Reports</b></A><br>
        <A HREF="ManageTables.php"><b>Manage Database</b></A>
        <?php
        // put your code here
        ?>
    </body>
</html>
